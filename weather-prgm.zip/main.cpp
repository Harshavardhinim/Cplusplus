/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    string id,loc;
    int report,weekreport;
    cout<<"                           WEATHER APP              \n";
    /*Name:Harshavardhini M 
    College name:Vivekanandha College of ENgineering for Women
    datas used:Email id,Location
    Methods used:Switch
    */
    cout<<"Email id:"<<id<<endl;
    cin>>id;
    cout<<"Current location:"<<loc;
    cin>>loc;
    cout<<"Report:\n";
    cin>>report;
    switch(report)
    {
        case 1:
        cout<<"today:cloudy";
        break;
        case 2:
        cout<<"Yesterday:sunny";
        break;
        case 3:
        cout<<"Tomorrow:rainy";
        break;
        case 4:
        cout<<"\nWeekly report:";
        cout<<"\nMonday:rainy";
        cout<<"\nTuesday:thuderstorm";
        cout<<"\nwednesday:Sunny";
        cout<<"\nThursday:Cloudy";
        cout<<"\nfriday:rainy";
        cout<<"\nsaturday:cloudy";
        break;
    }

    return 0;
}
